function handleReplyButton(responseId){
    const replyFormContainer = document.getElementById('reply-form-container-$(responseId)')
    if (reply-form-container){
        reply-form-container.className = "reply-form-container enabled";
    }
}